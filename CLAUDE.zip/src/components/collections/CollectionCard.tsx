"use client"

import { Play, Heart, Clock } from "lucide-react"
import { cn } from "@/lib/utils"
import { useAudioStore, useFavoritesStore } from "@/store"

interface CollectionCardProps {
  id: string
  title: string
  description: string
  gradient: string
  duration: number
  tags: string[]
  soundIds: string[]
  isPremium?: boolean
  className?: string
}

export function CollectionCard({
  id,
  title,
  description,
  gradient,
  duration,
  tags,
  soundIds,
  isPremium,
  className,
}: CollectionCardProps) {
  const { playSound } = useAudioStore()
  const { isCollectionFavorited, toggleCollection } = useFavoritesStore()
  const favorited = isCollectionFavorited(id)

  const formatDuration = (s: number) => {
    const h = Math.floor(s / 3600)
    const m = Math.floor((s % 3600) / 60)
    if (h > 0) return `${h}h ${m}m`
    return `${m} min`
  }

  const handlePlay = (e: React.MouseEvent) => {
    e.stopPropagation()
    soundIds.forEach((sid) => playSound(sid))
  }

  return (
    <div
      className={cn(
        "group relative cursor-pointer overflow-hidden rounded-2xl border border-white/5 transition-all duration-300 hover:scale-[1.02] hover:border-white/10",
        className
      )}
    >
      <div className={cn("absolute inset-0 bg-gradient-to-br opacity-60", gradient)} />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
      <div className="absolute inset-0 bg-black/20" />

      <div className="relative flex h-48 flex-col justify-end p-4">
        <div>
          <h3 className="text-lg font-semibold text-white">{title}</h3>
          <p className="mt-1 text-xs text-white/50 line-clamp-2">{description}</p>
          <div className="mt-2 flex items-center gap-2">
            <span className="flex items-center gap-1 text-[10px] text-white/40">
              <Clock size={10} />
              {formatDuration(duration)}
            </span>
            {isPremium && (
              <span className="rounded-full bg-amber-500/20 px-1.5 py-0.5 text-[9px] font-medium text-amber-400">
                Premium
              </span>
            )}
          </div>
          <div className="mt-2 flex flex-wrap gap-1">
            {tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="rounded-full bg-white/10 px-2 py-0.5 text-[9px] text-white/60"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        <div className="mt-3 flex items-center gap-2">
          <button
            onClick={handlePlay}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-500/80 text-white opacity-0 transition-all duration-300 group-hover:opacity-100 hover:bg-blue-400"
          >
            <Play size={14} />
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); toggleCollection(id) }}
            className={cn(
              "flex h-8 w-8 items-center justify-center rounded-full transition-colors",
              favorited
                ? "text-red-400"
                : "text-white/30 opacity-0 group-hover:opacity-100 hover:text-white/60"
            )}
          >
            <Heart size={14} fill={favorited ? "currentColor" : "none"} />
          </button>
        </div>
      </div>
    </div>
  )
}
