"use client"

import { Play, Pause, Heart, Clock } from "lucide-react"
import { cn } from "@/lib/utils"
import { useAudioStore, useFavoritesStore } from "@/store"

interface SoundCardProps {
  id: string
  title: string
  description: string
  gradient: string
  duration: number
  isPremium?: boolean
  className?: string
  onClick?: () => void
}

export function SoundCard({
  id,
  title,
  description,
  gradient,
  duration,
  isPremium,
  className,
  onClick,
}: SoundCardProps) {
  const { isSoundPlaying, toggleSound } = useAudioStore()
  const { isSoundFavorited, toggleSound: toggleFav } = useFavoritesStore()
  const playing = isSoundPlaying(id)
  const favorited = isSoundFavorited(id)

  const formatDuration = (s: number) => {
    const h = Math.floor(s / 3600)
    const m = Math.floor((s % 3600) / 60)
    if (h > 0) return `${h}h ${m}m`
    return `${m} min`
  }

  const handleClick = () => {
    if (onClick) onClick()
    else toggleSound(id)
  }

  return (
    <div
      className={cn(
        "group relative cursor-pointer overflow-hidden rounded-2xl border border-white/5 transition-all duration-300 hover:scale-[1.02] hover:border-white/10",
        className
      )}
      onClick={handleClick}
    >
      <div className={cn("absolute inset-0 bg-gradient-to-br opacity-60", gradient)} />
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
      <div className="absolute inset-0 bg-black/20" />

      <div className="relative flex h-40 flex-col justify-end p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h3 className="text-sm font-semibold text-white">{title}</h3>
            <p className="mt-0.5 text-xs text-white/50">{description}</p>
            <div className="mt-2 flex items-center gap-2">
              <span className="flex items-center gap-1 text-[10px] text-white/40">
                <Clock size={10} />
                {formatDuration(duration)}
              </span>
              {isPremium && (
                <span className="rounded-full bg-amber-500/20 px-1.5 py-0.5 text-[9px] font-medium text-amber-400">
                  Premium
                </span>
              )}
            </div>
          </div>
        </div>

        <div className="mt-3 flex items-center gap-2">
          <button
            onClick={(e) => { e.stopPropagation(); toggleSound(id) }}
            className="flex h-9 w-9 items-center justify-center rounded-full bg-blue-500/80 text-white opacity-0 transition-all duration-300 group-hover:opacity-100 hover:bg-blue-400"
          >
            {playing ? <Pause size={14} /> : <Play size={14} />}
          </button>
          <button
            onClick={(e) => { e.stopPropagation(); toggleFav(id) }}
            className={cn(
              "flex h-8 w-8 items-center justify-center rounded-full transition-colors",
              favorited
                ? "text-red-400"
                : "text-white/30 opacity-0 group-hover:opacity-100 hover:text-white/60"
            )}
          >
            <Heart size={14} fill={favorited ? "currentColor" : "none"} />
          </button>
        </div>
      </div>

      {playing && (
        <div className="absolute left-3 top-3 flex items-center gap-1.5">
          <span className="h-2 w-2 animate-pulse rounded-full bg-blue-400" />
          <span className="text-[10px] font-medium text-blue-400">Playing</span>
        </div>
      )}
    </div>
  )
}
