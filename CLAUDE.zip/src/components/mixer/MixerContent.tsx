"use client"

import { useState } from "react"
import {
  Volume2,
  VolumeX,
  Music,
  Trash2,
  Save,
  Plus,
  Layers,
} from "lucide-react"
import { useMixerStore, useAudioStore } from "@/store"
import { Slider } from "@/components/ui/Slider"
import { GlassCard } from "@/components/ui/GlassCard"
import { SoundCard } from "@/components/ui/SoundCard"
import { sounds } from "@/data/sounds"
import { cn } from "@/lib/utils"

export function MixerContent() {
  const { layers, masterVolume, setMasterVolume, addLayer, removeLayer, setLayerVolume, toggleMute, savePreset } = useMixerStore()
  const { toggleSound, isSoundPlaying } = useAudioStore()
  const [showAddPanel, setShowAddPanel] = useState(false)
  const [presetName, setPresetName] = useState("")
  const [showSaveDialog, setShowSaveDialog] = useState(false)

  const hasSolo = layers.some((l) => l.isSolo)
  const availableSounds = sounds.filter((s) => !layers.some((l) => l.soundId === s.id))

  const getSound = (soundId: string) => sounds.find((s) => s.id === soundId)

  return (
    <div className="space-y-6 pb-32">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Sound Mixer</h1>
          <p className="mt-1 text-sm text-white/40">
            Combine multiple sounds to create your perfect ambiance
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowSaveDialog(true)}
            disabled={layers.length === 0}
            className="flex items-center gap-1.5 rounded-lg border border-white/10 px-3 py-2 text-xs font-medium text-white/50 transition-colors hover:border-white/20 hover:text-white/70 disabled:opacity-30"
          >
            <Save size={14} />
            Save Mix
          </button>
          <button
            onClick={() => setShowAddPanel(!showAddPanel)}
            disabled={layers.length >= 10}
            className="flex items-center gap-1.5 rounded-lg bg-blue-500/20 px-3 py-2 text-xs font-medium text-blue-400 transition-colors hover:bg-blue-500/30 disabled:opacity-30"
          >
            <Plus size={14} />
            Add Sound
          </button>
        </div>
      </div>

      <GlassCard className="border-blue-500/10 bg-blue-500/[0.03]">
        <div className="mb-3 flex items-center gap-3">
          <Layers size={16} className="text-blue-400" />
          <span className="text-sm font-medium text-white/70">Master</span>
          <span className="text-xs text-white/30">{layers.length}/10 layers</span>
        </div>
        <div className="flex items-center gap-3">
          <Volume2 size={14} className="text-white/30" />
          <Slider value={masterVolume} onChange={setMasterVolume} className="flex-1" />
        </div>
      </GlassCard>

      {layers.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20 text-white/30">
          <Music size={40} className="mb-3 opacity-30" />
          <p className="text-lg">No sounds in your mix</p>
          <p className="mt-1 text-sm">Click &quot;Add Sound&quot; to start building your ambiance</p>
        </div>
      )}

      <div className="space-y-3">
        {layers.map((layer) => {
          const sound = getSound(layer.soundId)
          if (!sound) return null
          const isAudible = layer.isMuted || (hasSolo && !layer.isSolo) ? false : true

          return (
            <GlassCard key={layer.soundId} className="flex items-center gap-4">
              <div className={cn("h-10 w-10 flex-shrink-0 rounded-lg bg-gradient-to-br", sound.gradient)} />
              <div className="min-w-0 flex-1">
                <p className={cn("text-sm font-medium", isAudible ? "text-white" : "text-white/30")}>
                  {sound.title}
                </p>
                <p className="text-xs text-white/30 truncate">{sound.category}</p>
              </div>

              <div className="flex items-center gap-2">
                <Slider
                  value={layer.volume}
                  onChange={(v) => setLayerVolume(layer.soundId, v)}
                  size="sm"
                  className="w-20 sm:w-28"
                />
                <span className="w-8 text-right text-[10px] text-white/30">
                  {Math.round(layer.volume * 100)}%
                </span>
              </div>

              <div className="flex items-center gap-1">
                <button
                  onClick={() => {
                    toggleMute(layer.soundId)
                    if (isSoundPlaying(layer.soundId)) toggleSound(layer.soundId)
                  }}
                  className={cn(
                    "rounded-lg p-1.5 transition-colors",
                    layer.isMuted
                      ? "bg-red-500/20 text-red-400"
                      : "text-white/30 hover:text-white/60"
                  )}
                >
                  {layer.isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
                </button>
                <button
                  onClick={() => {
                    removeLayer(layer.soundId)
                    if (isSoundPlaying(layer.soundId)) toggleSound(layer.soundId)
                  }}
                  className="rounded-lg p-1.5 text-white/30 transition-colors hover:text-red-400"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </GlassCard>
          )
        })}
      </div>

      {showAddPanel && availableSounds.length > 0 && (
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-white/50">Add sounds to your mix</h3>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {availableSounds.map((sound) => (
              <div key={sound.id} className="relative">
                <SoundCard {...sound} />
                <button
                  onClick={() => {
                    addLayer(sound.id)
                    toggleSound(sound.id)
                  }}
                  className="absolute inset-0 z-10 flex items-center justify-center rounded-2xl bg-black/40 opacity-0 transition-opacity hover:opacity-100"
                >
                  <div className="flex items-center gap-1.5 rounded-full bg-blue-500 px-3 py-1.5 text-xs font-medium text-white">
                    <Plus size={12} />
                    Add to Mix
                  </div>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {showSaveDialog && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
          <GlassCard className="w-80 border-white/10">
            <h3 className="mb-3 text-sm font-semibold text-white">Save Mix</h3>
            <input
              type="text"
              placeholder="Mix name..."
              value={presetName}
              onChange={(e) => setPresetName(e.target.value)}
              className="mb-4 w-full rounded-lg border border-white/10 bg-white/5 px-3 py-2 text-sm text-white outline-none placeholder:text-white/20 focus:border-blue-500/50"
              autoFocus
            />
            <div className="flex gap-2">
              <button
                onClick={() => {
                  if (presetName.trim()) savePreset(presetName.trim())
                  setShowSaveDialog(false)
                  setPresetName("")
                }}
                className="flex-1 rounded-lg bg-blue-500/20 py-2 text-sm font-medium text-blue-400 transition-colors hover:bg-blue-500/30"
              >
                Save
              </button>
              <button
                onClick={() => setShowSaveDialog(false)}
                className="flex-1 rounded-lg bg-white/5 py-2 text-sm font-medium text-white/50 transition-colors hover:bg-white/10"
              >
                Cancel
              </button>
            </div>
          </GlassCard>
        </div>
      )}
    </div>
  )
}
