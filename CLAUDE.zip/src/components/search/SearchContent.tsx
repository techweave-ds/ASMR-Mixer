"use client"

import { useState, useMemo } from "react"
import { Search, X, TrendingUp, Clock } from "lucide-react"
import { useUiStore } from "@/store"
import { SoundCard } from "@/components/ui/SoundCard"
import { sounds } from "@/data/sounds"

export function SearchContent() {
  const { searchOpen, setSearchOpen, recentSearches, addRecentSearch, clearRecentSearches } = useUiStore()
  const [query, setQuery] = useState("")

  const results = useMemo(() => {
    if (!query.trim()) return []
    const q = query.toLowerCase()
    return sounds.filter(
      (s) =>
        s.title.toLowerCase().includes(q) ||
        s.tags.some((t) => t.toLowerCase().includes(q)) ||
        s.category.toLowerCase().includes(q) ||
        s.description.toLowerCase().includes(q)
    )
  }, [query])

  const trendingSounds = useMemo(() => sounds.slice(0, 6), [])

  if (!searchOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/95 backdrop-blur-xl">
      <div className="mx-auto max-w-2xl px-4 pt-12">
        <div className="relative">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            type="text"
            placeholder="Search sounds, categories, tags..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full rounded-2xl border border-white/10 bg-white/5 py-3.5 pl-12 pr-12 text-base text-white outline-none transition-colors placeholder:text-white/20 focus:border-blue-500/50"
            autoFocus
          />
          <button
            onClick={() => { setSearchOpen(false); setQuery("") }}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60"
          >
            <X size={18} />
          </button>
        </div>

        {query && results.length > 0 && (
          <div className="mt-6">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {results.map((sound) => (
                <SoundCard
                  key={sound.id}
                  {...sound}
                  onClick={() => { addRecentSearch(query); setSearchOpen(false); setQuery("") }}
                />
              ))}
            </div>
          </div>
        )}

        {query && results.length === 0 && (
          <div className="mt-16 text-center text-white/30">
            <p className="text-lg">No results for &ldquo;{query}&rdquo;</p>
            <p className="mt-1 text-sm">Try a different search term</p>
          </div>
        )}

        {!query && (
          <>
            {recentSearches.length > 0 && (
              <div className="mt-8">
                <div className="mb-3 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock size={14} className="text-white/30" />
                    <span className="text-sm font-medium text-white/50">Recent Searches</span>
                  </div>
                  <button onClick={clearRecentSearches} className="text-xs text-white/20 hover:text-white/50">
                    Clear All
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {recentSearches.map((s) => (
                    <button
                      key={s}
                      onClick={() => setQuery(s)}
                      className="rounded-full bg-white/5 px-3 py-1.5 text-xs text-white/50 transition-colors hover:bg-white/10"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-8">
              <div className="mb-3 flex items-center gap-2">
                <TrendingUp size={14} className="text-white/30" />
                <span className="text-sm font-medium text-white/50">Trending Sounds</span>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                {trendingSounds.map((sound) => (
                  <SoundCard key={sound.id} {...sound} />
                ))}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
