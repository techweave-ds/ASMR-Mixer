"use client"

import { useState } from "react"
import { Play, Pause, Heart, Volume2, Timer, X, Music } from "lucide-react"
import { useAudioStore, useFavoritesStore } from "@/store"
import { Slider } from "@/components/ui/Slider"
import { cn } from "@/lib/utils"
import { sounds } from "@/data/sounds"

const TIMER_OPTIONS = [15, 30, 45, 60, 120]

export function PlayerBar() {
  const { isPlaying, isPlayingSounds, volume, setMasterVolume, stopAll, stopSound, timerMinutes, setTimer, cancelTimer } = useAudioStore()
  const { isSoundFavorited, toggleSound: toggleFav } = useFavoritesStore()
  const [showTimer, setShowTimer] = useState(false)

  const playingArray = Array.from(isPlayingSounds)

  if (playingArray.length === 0) return null

  const getTitle = (id: string) => {
    const s = sounds.find((sd) => sd.id === id)
    return s ? s.title : id
  }

  const firstSound = sounds.find((s) => s.id === playingArray[0])

  return (
    <div className="fixed bottom-16 left-0 right-0 z-40 border-t border-white/5 bg-black/80 backdrop-blur-xl lg:bottom-0">
      <div className="flex items-center gap-3 px-3 py-2.5 sm:gap-4 sm:px-4">
        <div className={cn("h-9 w-9 flex-shrink-0 rounded-lg bg-gradient-to-br sm:h-10 sm:w-10", firstSound?.gradient ?? "from-blue-400 to-indigo-600")} />
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-white">
            {playingArray.length === 1 ? getTitle(playingArray[0]) : `${playingArray.length} sounds playing`}
          </p>
          <p className="truncate text-xs text-white/40">
            {playingArray.slice(0, 3).map((id) => getTitle(id)).join(", ")}
            {playingArray.length > 3 && ` +${playingArray.length - 3} more`}
          </p>
        </div>

        <div className="flex items-center gap-1.5 sm:gap-2">
          <button
            onClick={() => stopAll()}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-white/10 transition-colors hover:bg-white/20"
          >
            {isPlaying ? <Pause size={14} className="text-white" /> : <Play size={14} className="text-white" />}
          </button>
        </div>

        <div className="hidden items-center gap-3 sm:flex">
          <Volume2 size={14} className="text-white/30" />
          <Slider value={volume} onChange={setMasterVolume} className="w-20" size="sm" />
        </div>

        <div className="flex items-center gap-1.5">
          {playingArray.length === 1 && (
            <button
              onClick={() => toggleFav(playingArray[0])}
              className={cn("transition-colors", isSoundFavorited(playingArray[0]) ? "text-red-400" : "text-white/30 hover:text-white/60")}
            >
              <Heart size={15} fill={isSoundFavorited(playingArray[0]) ? "currentColor" : "none"} />
            </button>
          )}

          <div className="relative">
            <button
              onClick={() => setShowTimer(!showTimer)}
              className={cn("transition-colors", timerMinutes ? "text-blue-400" : "text-white/30 hover:text-white/60")}
            >
              <Timer size={15} />
            </button>
            {showTimer && (
              <div className="absolute bottom-full right-0 mb-2 w-48 rounded-xl border border-white/10 bg-black/90 p-3 backdrop-blur-xl">
                <div className="mb-2 flex items-center justify-between">
                  <span className="text-xs font-medium text-white/70">Sleep Timer</span>
                  {timerMinutes && <button onClick={cancelTimer} className="text-white/30 hover:text-white/60"><X size={12} /></button>}
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {TIMER_OPTIONS.map((m) => (
                    <button
                      key={m}
                      onClick={() => setTimer(timerMinutes === m ? null : m)}
                      className={cn(
                        "rounded-lg px-3 py-1.5 text-xs font-medium transition-colors",
                        timerMinutes === m ? "bg-blue-500/20 text-blue-400" : "bg-white/5 text-white/50 hover:bg-white/10 hover:text-white/70"
                      )}
                    >
                      {m >= 60 ? `${m / 60}h` : `${m}m`}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {playingArray.length > 1 && (
        <div className="flex gap-1.5 overflow-x-auto border-t border-white/5 px-3 py-1.5 scrollbar-none">
          {playingArray.map((id) => {
            const sd = sounds.find((s) => s.id === id)
            return (
              <button
                key={id}
                onClick={() => stopSound(id)}
                className="flex items-center gap-1 rounded-full bg-white/5 px-2 py-1 text-[10px] text-white/50 transition-colors hover:bg-white/10 hover:text-white/70"
              >
                <Music size={10} />
                <span className="max-w-[80px] truncate">{sd?.title ?? id}</span>
                <X size={10} className="ml-0.5" />
              </button>
            )
          })}
        </div>
      )}
    </div>
  )
}
