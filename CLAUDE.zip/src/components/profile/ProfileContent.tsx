"use client"

import { User, Moon, Sun, Bell, Trash2, Timer, Music, Volume2 } from "lucide-react"
import { useSettingsStore } from "@/store"
import { GlassCard } from "@/components/ui/GlassCard"
import { Slider } from "@/components/ui/Slider"
import { cn } from "@/lib/utils"

export function ProfileContent() {
  const {
    theme,
    setTheme,
    crossfadeDuration,
    setCrossfadeDuration,
    defaultSleepTimer,
    setDefaultSleepTimer,
    notificationsEnabled,
    setNotificationsEnabled,
    dailyReminder,
    setDailyReminder,
    reducedMotion,
    setReducedMotion,
  } = useSettingsStore()

  const timerOptions = [15, 30, 45, 60, 120]

  return (
    <div className="space-y-8 pb-32">
      <div>
        <h1 className="text-2xl font-bold text-white">Profile</h1>
        <p className="mt-1 text-sm text-white/40">Manage your account and preferences</p>
      </div>

      <section>
        <GlassCard className="flex items-center gap-4">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-blue-400 to-indigo-600">
            <User size={28} className="text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-white">Listener</h2>
            <p className="text-sm text-white/40">Premium Member</p>
          </div>
        </GlassCard>
      </section>

      <section>
        <h2 className="mb-4 text-lg font-semibold text-white/80">Preferences</h2>

        <GlassCard className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {theme === "dark" ? <Moon size={16} className="text-blue-400" /> : <Sun size={16} className="text-amber-400" />}
              <div>
                <p className="text-sm font-medium text-white">Theme</p>
                <p className="text-xs text-white/30">{theme === "dark" ? "Dark" : "Light"}</p>
              </div>
            </div>
            <button
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className={cn(
                "rounded-full px-3 py-1 text-xs font-medium",
                theme === "dark"
                  ? "bg-blue-500/20 text-blue-400"
                  : "bg-amber-500/20 text-amber-400"
              )}
            >
              {theme === "dark" ? "Dark" : "Light"}
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bell size={16} className="text-white/40" />
              <div>
                <p className="text-sm font-medium text-white">Notifications</p>
                <p className="text-xs text-white/30">Enable app notifications</p>
              </div>
            </div>
            <button
              onClick={() => setNotificationsEnabled(!notificationsEnabled)}
              className={cn(
                "rounded-full px-3 py-1 text-xs font-medium",
                notificationsEnabled
                  ? "bg-green-500/20 text-green-400"
                  : "bg-white/5 text-white/30"
              )}
            >
              {notificationsEnabled ? "On" : "Off"}
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bell size={16} className="text-white/40" />
              <div>
                <p className="text-sm font-medium text-white">Daily Reminder</p>
                <p className="text-xs text-white/30">&quot;Time to relax&quot; reminder</p>
              </div>
            </div>
            <button
              onClick={() => setDailyReminder(!dailyReminder)}
              className={cn(
                "rounded-full px-3 py-1 text-xs font-medium",
                dailyReminder
                  ? "bg-green-500/20 text-green-400"
                  : "bg-white/5 text-white/30"
              )}
            >
              {dailyReminder ? "On" : "Off"}
            </button>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Volume2 size={16} className="text-white/40" />
              <div>
                <p className="text-sm font-medium text-white">Crossfade</p>
                <p className="text-xs text-white/30">{crossfadeDuration}s transition</p>
              </div>
            </div>
            <Slider
              value={crossfadeDuration}
              onChange={setCrossfadeDuration}
              min={0}
              max={5}
              step={0.5}
              size="sm"
              className="w-24"
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Timer size={16} className="text-white/40" />
              <div>
                <p className="text-sm font-medium text-white">Default Sleep Timer</p>
                <p className="text-xs text-white/30">
                  {defaultSleepTimer ? `${defaultSleepTimer} min` : "No default"}
                </p>
              </div>
            </div>
            <div className="flex gap-1">
              {timerOptions.map((m) => (
                <button
                  key={m}
                  onClick={() => setDefaultSleepTimer(defaultSleepTimer === m ? null : m)}
                  className={cn(
                    "rounded-md px-2 py-1 text-[10px] font-medium",
                    defaultSleepTimer === m
                      ? "bg-blue-500/20 text-blue-400"
                      : "bg-white/5 text-white/30 hover:text-white/50"
                  )}
                >
                  {m >= 60 ? `${m / 60}h` : `${m}m`}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Music size={16} className="text-white/40" />
              <div>
                <p className="text-sm font-medium text-white">Reduced Motion</p>
                <p className="text-xs text-white/30">Minimize animations</p>
              </div>
            </div>
            <button
              onClick={() => setReducedMotion(!reducedMotion)}
              className={cn(
                "rounded-full px-3 py-1 text-xs font-medium",
                reducedMotion
                  ? "bg-green-500/20 text-green-400"
                  : "bg-white/5 text-white/30"
              )}
            >
              {reducedMotion ? "On" : "Off"}
            </button>
          </div>
        </GlassCard>
      </section>

      <section>
        <h2 className="mb-4 text-lg font-semibold text-white/80">Storage</h2>
        <GlassCard>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Trash2 size={16} className="text-white/40" />
              <div>
                <p className="text-sm font-medium text-white">Clear Cache</p>
                <p className="text-xs text-white/30">Free up storage space</p>
              </div>
            </div>
            <button className="rounded-lg border border-red-500/20 px-3 py-1.5 text-xs font-medium text-red-400 transition-colors hover:bg-red-500/10">
              Clear
            </button>
          </div>
        </GlassCard>
      </section>

      <section>
        <h2 className="mb-4 text-lg font-semibold text-white/80">About</h2>
        <GlassCard className="space-y-2 text-sm text-white/40">
          <p>Silent Circuit v1.0.0</p>
          <p>Premium ASMR & Ambient Sound Application</p>
          <div className="flex gap-4 pt-1">
            <button className="text-xs text-white/30 underline hover:text-white/50">Privacy Policy</button>
            <button className="text-xs text-white/30 underline hover:text-white/50">Terms of Service</button>
            <button className="text-xs text-white/30 underline hover:text-white/50">Send Feedback</button>
          </div>
        </GlassCard>
      </section>
    </div>
  )
}
