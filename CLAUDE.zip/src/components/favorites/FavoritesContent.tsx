"use client"

import { useMemo } from "react"
import { Heart, Music, Bookmark } from "lucide-react"
import { SoundCard } from "@/components/ui/SoundCard"
import { CollectionCard } from "@/components/collections/CollectionCard"
import { useFavoritesStore } from "@/store"
import { sounds } from "@/data/sounds"
import { collections } from "@/data/collections"

export function FavoritesContent() {
  const { soundIds, collectionIds } = useFavoritesStore()

  const favoriteSounds = useMemo(
    () => sounds.filter((s) => soundIds.includes(s.id)),
    [soundIds]
  )
  const favoriteCollections = useMemo(
    () => collections.filter((c) => collectionIds.includes(c.id)),
    [collectionIds]
  )

  const hasFavorites = favoriteSounds.length > 0 || favoriteCollections.length > 0

  if (!hasFavorites) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-white/30">
        <Heart size={48} className="mb-4 opacity-30" />
        <p className="text-lg">No favorites yet</p>
        <p className="mt-1 text-sm text-center">
          Tap the heart icon on sounds and collections to save them here
        </p>
      </div>
    )
  }

  return (
    <div className="space-y-8 pb-32">
      <div>
        <h1 className="text-2xl font-bold text-white">Favorites</h1>
        <p className="mt-1 text-sm text-white/40">Your saved sounds and collections</p>
      </div>

      {favoriteSounds.length > 0 && (
        <section>
          <div className="mb-4 flex items-center gap-2">
            <Music size={16} className="text-blue-400" />
            <h2 className="text-lg font-semibold text-white/80">Sounds</h2>
            <span className="text-xs text-white/30">({favoriteSounds.length})</span>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
            {favoriteSounds.map((sound) => (
              <SoundCard key={sound.id} {...sound} />
            ))}
          </div>
        </section>
      )}

      {favoriteCollections.length > 0 && (
        <section>
          <div className="mb-4 flex items-center gap-2">
            <Bookmark size={16} className="text-blue-400" />
            <h2 className="text-lg font-semibold text-white/80">Collections</h2>
            <span className="text-xs text-white/30">({favoriteCollections.length})</span>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {favoriteCollections.map((col) => (
              <CollectionCard key={col.id} {...col} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
