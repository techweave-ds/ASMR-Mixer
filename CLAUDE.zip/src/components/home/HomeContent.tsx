"use client"

import { useMemo } from "react"
import { SoundCard } from "@/components/ui/SoundCard"
import { CollectionCard } from "@/components/collections/CollectionCard"
import { GlassCard } from "@/components/ui/GlassCard"
import { getFeaturedSounds } from "@/data/sounds"
import { collections } from "@/data/collections"

const quickCategories = [
  { label: "Sleep", gradient: "from-indigo-600 to-purple-900", icon: "Moon", soundId: "brown-noise" },
  { label: "Study", gradient: "from-blue-500 to-teal-700", icon: "BookOpen", soundId: "library-quiet" },
  { label: "Focus", gradient: "from-emerald-500 to-green-800", icon: "Target", soundId: "white-noise" },
  { label: "Relax", gradient: "from-sky-400 to-blue-600", icon: "CloudSun", soundId: "ocean-waves" },
  { label: "Meditation", gradient: "from-violet-500 to-purple-900", icon: "Flower2", soundId: "space-ambient" },
  { label: "Reading", gradient: "from-amber-500 to-orange-700", icon: "BookMarked", soundId: "fireplace" },
  { label: "Work", gradient: "from-stone-400 to-stone-700", icon: "Briefcase", soundId: "cafe-bustling" },
]

export function HomeContent() {
  const featuredSounds = useMemo(() => getFeaturedSounds(), [])
  const featuredCollections = useMemo(() => collections.filter((c) => !c.isPremium).slice(0, 4), [])

  const getHour = () => new Date().getHours()
  const greeting = getHour() < 12 ? "Good Morning" : getHour() < 18 ? "Good Afternoon" : "Good Evening"

  return (
    <div className="space-y-8 pb-32">
      <section>
        <h1 className="text-3xl font-bold text-white">{greeting}</h1>
        <p className="mt-1 text-sm text-white/40">What would you like to do today?</p>
      </section>

      <section>
        <h2 className="mb-4 text-lg font-semibold text-white/80">Quick Categories</h2>
        <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
          {quickCategories.map((cat) => (
            <GlassCard
              key={cat.label}
              hover
              className="flex min-w-[120px] flex-col items-center gap-2 py-4"
            >
              <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${cat.gradient}`}>
                <div className="h-5 w-5 rounded-full bg-white/30" />
              </div>
              <span className="text-xs font-medium text-white/70">{cat.label}</span>
            </GlassCard>
          ))}
        </div>
      </section>

      <section>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white/80">Featured Collections</h2>
          <span className="text-xs text-white/30">Curated for you</span>
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {featuredCollections.map((col) => (
            <CollectionCard key={col.id} {...col} />
          ))}
        </div>
      </section>

      <section>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-white/80">Popular Sounds</h2>
          <span className="text-xs text-white/30">Most played</span>
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
          {featuredSounds.map((sound) => (
            <SoundCard key={sound.id} {...sound} />
          ))}
        </div>
      </section>

      <section>
        <h2 className="mb-4 text-lg font-semibold text-white/80">Recently Played</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4">
          {featuredSounds.slice(0, 4).map((sound) => (
            <SoundCard key={sound.id} {...sound} />
          ))}
        </div>
      </section>
    </div>
  )
}
