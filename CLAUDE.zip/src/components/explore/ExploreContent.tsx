"use client"

import { useState, useMemo } from "react"
import { Search } from "lucide-react"
import { SoundCard } from "@/components/ui/SoundCard"
import { GlassCard } from "@/components/ui/GlassCard"
import { sounds, categoryLabels } from "@/data/sounds"
import { cn } from "@/lib/utils"

const categories = Object.keys(categoryLabels)

export function ExploreContent() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [searchQuery, setSearchQuery] = useState("")

  const filteredSounds = useMemo(() => {
    let result = sounds
    if (selectedCategory) {
      result = result.filter((s) => s.category === selectedCategory)
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase()
      result = result.filter(
        (s) =>
          s.title.toLowerCase().includes(q) ||
          s.tags.some((t) => t.toLowerCase().includes(q)) ||
          categoryLabels[s.category]?.toLowerCase().includes(q)
      )
    }
    return result
  }, [selectedCategory, searchQuery])

  return (
    <div className="space-y-6 pb-32">
      <div>
        <h1 className="text-2xl font-bold text-white">Explore</h1>
        <p className="mt-1 text-sm text-white/40">Discover sounds that match your mood</p>
      </div>

      <div className="relative">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/30" />
        <input
          type="text"
          placeholder="Search sounds, categories, tags..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full rounded-xl border border-white/10 bg-white/5 py-2.5 pl-10 pr-4 text-sm text-white outline-none transition-colors placeholder:text-white/20 focus:border-blue-500/50"
        />
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setSelectedCategory(null)}
          className={cn(
            "rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
            !selectedCategory
              ? "bg-blue-500/20 text-blue-400"
              : "bg-white/5 text-white/40 hover:bg-white/10 hover:text-white/60"
          )}
        >
          All
        </button>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(selectedCategory === cat ? null : cat)}
            className={cn(
              "rounded-full px-3 py-1.5 text-xs font-medium capitalize transition-colors",
              selectedCategory === cat
                ? "bg-blue-500/20 text-blue-400"
                : "bg-white/5 text-white/40 hover:bg-white/10 hover:text-white/60"
            )}
          >
            {categoryLabels[cat]}
          </button>
        ))}
      </div>

      {selectedCategory && (
        <GlassCard className="border-blue-500/10 bg-blue-500/5">
          <p className="text-sm text-blue-300/80">
            Showing sounds in{" "}
            <span className="font-medium text-blue-300">{categoryLabels[selectedCategory]}</span>
          </p>
        </GlassCard>
      )}

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
        {filteredSounds.map((sound) => (
          <SoundCard key={sound.id} {...sound} />
        ))}
      </div>

      {filteredSounds.length === 0 && (
        <div className="flex flex-col items-center justify-center py-16 text-white/30">
          <p className="text-lg">No sounds found</p>
          <p className="mt-1 text-sm">Try a different category or search term</p>
        </div>
      )}
    </div>
  )
}
