"use client"

import { useEffect } from "react"
import { BottomNav } from "@/components/layout/BottomNav"
import { Sidebar, TopBar } from "@/components/layout/Sidebar"
import { PlayerBar } from "@/components/player/PlayerBar"
import { SearchContent } from "@/components/search/SearchContent"
import { useSettingsStore } from "@/store"

export function Providers({ children }: { children: React.ReactNode }) {
  const { theme, reducedMotion } = useSettingsStore()

  useEffect(() => {
    document.documentElement.classList.toggle("dark", theme === "dark")
    document.documentElement.classList.toggle("reduce-motion", reducedMotion)
  }, [theme, reducedMotion])

  return (
    <>
      <div className="flex min-h-screen bg-[#0a0a0f]">
        <Sidebar />
        <div className="flex flex-1 flex-col lg:ml-64">
          <TopBar />
          <main className="flex-1 px-4 py-6 lg:px-8">{children}</main>
        </div>
      </div>
      <PlayerBar />
      <BottomNav />
      <SearchContent />
    </>
  )
}
