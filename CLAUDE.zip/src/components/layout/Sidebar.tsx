"use client"

import { Home, Compass, SlidersVertical, Heart, User, Search } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useUiStore } from "@/store"
import { cn } from "@/lib/utils"

const sidebarItems = [
  { href: "/", icon: Home, label: "Home" },
  { href: "/explore", icon: Compass, label: "Explore" },
  { href: "/mixer", icon: SlidersVertical, label: "Mixer" },
  { href: "/favorites", icon: Heart, label: "Favorites" },
]

export function Sidebar() {
  const pathname = usePathname()
  const { sidebarOpen, setSidebarOpen } = useUiStore()

  return (
    <>
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      <aside
        className={cn(
          "fixed left-0 top-0 z-50 flex h-full w-64 flex-col border-r border-white/5 bg-black/90 backdrop-blur-xl transition-transform duration-300 lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex h-14 items-center gap-2 border-b border-white/5 px-6">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-500/20">
            <div className="h-4 w-4 rounded-full bg-blue-400" />
          </div>
          <span className="text-lg font-semibold text-white">Silent Circuit</span>
        </div>

        <nav className="flex-1 space-y-1 p-3">
          {sidebarItems.map(({ href, icon: Icon, label }) => {
            const isActive = pathname === href
            return (
              <Link
                key={href}
                href={href}
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
                  isActive
                    ? "bg-blue-500/10 text-blue-400"
                    : "text-white/50 hover:bg-white/5 hover:text-white/80"
                )}
              >
                <Icon size={18} />
                {label}
              </Link>
            )
          })}
        </nav>

        <div className="border-t border-white/5 p-3">
          <Link
            href="/profile"
            onClick={() => setSidebarOpen(false)}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors",
              pathname === "/profile"
                ? "bg-blue-500/10 text-blue-400"
                : "text-white/50 hover:bg-white/5 hover:text-white/80"
            )}
          >
            <User size={18} />
            Profile
          </Link>
        </div>
      </aside>
    </>
  )
}

export function TopBar() {
  const { setSearchOpen } = useUiStore()

  return (
    <header className="hidden h-14 items-center gap-4 border-b border-white/5 px-6 lg:flex">
      <button
        onClick={() => setSearchOpen(true)}
        className="flex flex-1 items-center gap-3 rounded-lg border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/30 transition-colors hover:border-white/20 hover:text-white/50"
      >
        <Search size={16} />
        Search sounds, categories, collections...
      </button>
    </header>
  )
}
