import { Home, Compass, SlidersVertical, Heart, User } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"

const navItems = [
  { href: "/", icon: Home, label: "Home" },
  { href: "/explore", icon: Compass, label: "Explore" },
  { href: "/mixer", icon: SlidersVertical, label: "Mixer" },
  { href: "/favorites", icon: Heart, label: "Favorites" },
  { href: "/profile", icon: User, label: "Profile" },
]

export function BottomNav() {
  const pathname = usePathname()

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 flex items-center justify-around border-t border-white/5 bg-black/80 px-2 pb-safe backdrop-blur-xl lg:hidden">
      {navItems.map(({ href, icon: Icon, label }) => {
        const isActive = pathname === href
        return (
          <Link
            key={href}
            href={href}
            className="flex flex-col items-center gap-0.5 px-3 py-2 transition-colors"
          >
            <Icon
              size={20}
              className={isActive ? "text-blue-400" : "text-white/40"}
            />
            <span
              className={`text-[10px] font-medium ${
                isActive ? "text-blue-400" : "text-white/40"
              }`}
            >
              {label}
            </span>
          </Link>
        )
      })}
    </nav>
  )
}
